print("Ecommerce initialized.")
